<p align="center">
  <img src="./assets/race-intro.gif" width="100%" alt="Nigel Fernandes — animated F1 start lights and racing intro" />
</p>

<p align="center">
  <a href="#01--driver-data">DRIVER</a> &nbsp; / &nbsp;
  <a href="#02--the-tech-garage">TECH GARAGE</a> &nbsp; / &nbsp;
  <a href="#03--the-project-grid">PROJECTS</a> &nbsp; / &nbsp;
  <a href="#04--career-lap-chart">LAP HISTORY</a> &nbsp; / &nbsp;
  <a href="#06--team-radio">TEAM RADIO</a>
</p>

<p align="center"><sub><a href="./STATIC.md">View the motion-free edition</a></sub></p>

### 01 / DRIVER DATA

I'm **Nigel Fernandes** — an Electronics and Computer Science student at **CRCE, Mumbai**, building across web development, design, and creative technology. Off track, I make music and bring people together through events.

<picture><source media="(max-width: 600px)" srcset="./assets/garage/driver-data-mobile.gif" /><img src="./assets/garage/driver-data.gif" width="100%" alt="Driver data: B.Tech ECS at CRCE, 2025–2029; Technical Representative; based in Mumbai, India." /></picture>

### 02 / THE TECH GARAGE

Tools from my projects and learning journey. **Tap a logo to explore.**

<p align="center">
  <a href="https://react.dev/"><picture><source media="(max-width: 600px)" srcset="./assets/garage/tech-react-mobile.gif" /><img src="./assets/garage/tech-react.gif" width="32%" alt="React — interfaces" /></picture></a>
  <a href="https://nextjs.org/"><picture><source media="(max-width: 600px)" srcset="./assets/garage/tech-nextdotjs-mobile.gif" /><img src="./assets/garage/tech-nextdotjs.gif" width="32%" alt="Next.js — web framework" /></picture></a>
  <a href="https://www.typescriptlang.org/"><picture><source media="(max-width: 600px)" srcset="./assets/garage/tech-typescript-mobile.gif" /><img src="./assets/garage/tech-typescript.gif" width="32%" alt="TypeScript — typed javascript" /></picture></a>
</p>

<p align="center">
  <a href="https://tailwindcss.com/"><picture><source media="(max-width: 600px)" srcset="./assets/garage/tech-tailwindcss-mobile.gif" /><img src="./assets/garage/tech-tailwindcss.gif" width="32%" alt="Tailwind CSS — styling" /></picture></a>
  <a href="https://motion.dev/"><picture><source media="(max-width: 600px)" srcset="./assets/garage/tech-framer-mobile.gif" /><img src="./assets/garage/tech-framer.gif" width="32%" alt="Framer Motion — animation" /></picture></a>
  <a href="https://vite.dev/"><picture><source media="(max-width: 600px)" srcset="./assets/garage/tech-vite-mobile.gif" /><img src="./assets/garage/tech-vite.gif" width="32%" alt="Vite — build tooling" /></picture></a>
</p>

<p align="center">
  <a href="https://nodejs.org/"><picture><source media="(max-width: 600px)" srcset="./assets/garage/tech-nodedotjs-mobile.gif" /><img src="./assets/garage/tech-nodedotjs.gif" width="32%" alt="Node.js — server runtime" /></picture></a>
  <a href="https://expressjs.com/"><picture><source media="(max-width: 600px)" srcset="./assets/garage/tech-express-mobile.gif" /><img src="./assets/garage/tech-express.gif" width="32%" alt="Express — api routing" /></picture></a>
  <a href="https://sqlite.org/"><picture><source media="(max-width: 600px)" srcset="./assets/garage/tech-sqlite-mobile.gif" /><img src="./assets/garage/tech-sqlite.gif" width="32%" alt="SQLite — data storage" /></picture></a>
</p>

<p align="center">
  <a href="https://www.python.org/"><picture><source media="(max-width: 600px)" srcset="./assets/garage/tech-python-mobile.gif" /><img src="./assets/garage/tech-python.gif" width="32%" alt="Python — foundations" /></picture></a>
  <a href="https://github.com/Nigel777123?tab=repositories"><picture><source media="(max-width: 600px)" srcset="./assets/garage/tech-github-mobile.gif" /><img src="./assets/garage/tech-github.gif" width="32%" alt="GitHub — repositories" /></picture></a>
  <a href="https://ai.google.dev/"><picture><source media="(max-width: 600px)" srcset="./assets/garage/tech-googlegemini-mobile.gif" /><img src="./assets/garage/tech-googlegemini.gif" width="32%" alt="Gemini — ai integration" /></picture></a>
</p>

<details>
<summary><strong>Open the garage manifest — stack & credentials</strong></summary>

- **Frontend:** React, Next.js, TypeScript, Tailwind CSS
- **Motion & tooling:** Framer Motion, Vite, GitHub
- **Backend & data:** Node.js, Express, SQLite
- **AI & learning:** Gemini integration, Python fundamentals, generative AI foundations
- **Credentials:** Career Essentials in Generative AI by Microsoft and LinkedIn; Introduction to Programming Using Python; Hack Into PCell 2025

Stack references: [portfolio](https://github.com/Nigel777123/personal-portfolio), [Campus Reconnect](https://github.com/Nigel777123/Campus_Reconnect), and [qrgpt](https://github.com/Nigel777123/qrgpt).

</details>

### 03 / THE PROJECT GRID

**Select a project to open its repository.**

<p align="center">
  <a href="https://github.com/Nigel777123/personal-portfolio"><picture><source media="(max-width: 600px)" srcset="./assets/garage/project-portfolio-mobile.gif" /><img src="./assets/garage/project-portfolio.gif" width="32%" alt="Personal Portfolio: F1-inspired interface design. Open repository." /></picture></a>
  <a href="https://github.com/Nigel777123/Campus_Reconnect"><picture><source media="(max-width: 600px)" srcset="./assets/garage/project-campus-mobile.gif" /><img src="./assets/garage/project-campus.gif" width="32%" alt="Campus Reconnect: Campus lost-and-found app. Open repository." /></picture></a>
  <a href="https://github.com/Nigel777123/ASL_detect"><picture><source media="(max-width: 600px)" srcset="./assets/garage/project-asl-mobile.gif" /><img src="./assets/garage/project-asl.gif" width="32%" alt="Asl Detect: Sign-language project. Open repository." /></picture></a>
</p>

<p align="center"><a href="https://github.com/Nigel777123?tab=repositories">Explore the full garage ↗</a></p>

### 04 / CAREER LAP CHART

<picture><source media="(max-width: 600px)" srcset="./assets/garage/career-laps-mobile.gif" /><img src="./assets/garage/career-laps.gif" width="100%" alt="Career lap chart: Spotify verified in 2023, released Golden Days in 2024, started B.Tech ECS in 2025, Technical Representative at CRCE in 2026." /></picture>

<details>
<summary><strong>Read the race log — experience & milestones</strong></summary>

- **2026:** Technical Representative at CRCE, following event management experience with IEEExCRCE.
- **2025:** Began B.Tech in Electronics and Computer Science at CRCE.
- **2024:** Released *Golden Days* with friends, drawing on experimentation, AI, and independently learned music production skills.
- **2023:** Achieved verified artist status on Spotify.

</details>

<picture><source media="(max-width: 600px)" srcset="./assets/garage/off-track-mobile.gif" /><img src="./assets/garage/off-track.gif" width="100%" alt="Off track: guitar, music production, generative AI, and event management, with an animated audio equalizer." /></picture>

<details>
<summary><strong>Switch to the creative channel</strong></summary>

**Sound:** Acoustic guitar, music theory, music production.<br />
**People:** Marketing strategy, public relations, event management.<br />
**Languages:** English, Hindi, Marathi.

</details>

### 06 / TEAM RADIO

<a href="mailto:nigelferns2211@gmail.com"><picture><source media="(max-width: 600px)" srcset="./assets/garage/team-radio-mobile.gif" /><img src="./assets/garage/team-radio.gif" width="100%" alt="Team radio — let's build the next thing. Click to email Nigel." /></picture></a>

<p align="center">
  <strong><a href="mailto:nigelferns2211@gmail.com">SEND A TRANSMISSION ↗</a></strong>
  &nbsp; / &nbsp;
  <strong><a href="https://www.linkedin.com/in/nigelferns/">LINKEDIN ↗</a></strong>
  &nbsp; / &nbsp;
  <strong><a href="https://github.com/Nigel777123?tab=repositories">GITHUB ↗</a></strong>
</p>

<p align="center"><sub>BUILT WITH CURIOSITY. TUNED THROUGH PRACTICE. &nbsp; / &nbsp; SEE YOU ON THE NEXT LAP.</sub></p>
